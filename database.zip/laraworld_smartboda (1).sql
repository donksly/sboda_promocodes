-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 28, 2018 at 10:44 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laraworld_smartboda`
--

-- --------------------------------------------------------

--
-- Table structure for table `codes`
--

CREATE TABLE `codes` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `generated_codes`
--

CREATE TABLE `generated_codes` (
  `id` int(10) UNSIGNED NOT NULL,
  `amount_id` int(10) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `enc_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `promo_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `voucher_amount` int(11) NOT NULL,
  `active_state` smallint(6) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `generated_codes`
--

INSERT INTO `generated_codes` (`id`, `amount_id`, `email`, `enc_email`, `promo_code`, `voucher_amount`, `active_state`, `created_at`, `updated_at`) VALUES
(1, 2, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '43b10ed7', 1666, 0, '2018-06-22 08:57:18', '2018-06-22 09:57:12'),
(2, 17, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '42600ece', 3500, 0, '2018-06-22 09:34:21', '2018-06-22 09:57:12'),
(3, 18, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '43170ed3', 3500, 0, '2018-06-22 09:34:53', '2018-06-22 09:57:13'),
(4, 19, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '42ab0ed0', 3500, 0, '2018-06-22 09:36:11', '2018-06-22 09:57:13'),
(5, 19, 'hgf@ghf.hgf', '9507b036e4b714eb603d02f6b157da8c', 'a8a60a69', 3500, 0, '2018-06-22 09:36:11', '2018-06-22 09:57:13'),
(6, 20, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '41570ec7', 3500, 0, '2018-06-22 09:40:23', '2018-06-22 09:57:13'),
(7, 20, 'hgf@ghf.hgf', '9507b036e4b714eb603d02f6b157da8c', 'a7b50a60', 3500, 0, '2018-06-22 09:40:23', '2018-06-22 09:57:13'),
(8, 21, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '41c40eca', 3500, 0, '2018-06-22 09:40:35', '2018-06-22 09:57:13'),
(9, 21, 'hgf@ghf.hgf', '9507b036e4b714eb603d02f6b157da8c', 'a81a0a64', 3500, 0, '2018-06-22 09:40:36', '2018-06-22 09:57:13'),
(10, 22, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '427e0ecf', 2333, 0, '2018-06-22 09:56:25', '2018-06-22 09:57:13'),
(11, 22, 'ff@gg.jt', '6a308976fc0ab627c93780e35f1daaa3', '87d00941', 2333, 0, '2018-06-22 09:56:25', '2018-06-22 09:57:13'),
(12, 22, 'fh@yuh.hf', '2d7d7a97d38be4fd3aab778ae7546639', '943b09bb', 2333, 0, '2018-06-22 09:56:25', '2018-06-22 09:57:13'),
(13, 23, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '41a30ec9', 2333, 0, '2018-06-22 09:57:13', '2018-06-22 10:43:16'),
(14, 23, 'ff@gg.jt', '6a308976fc0ab627c93780e35f1daaa3', '8749093b', 2333, 0, '2018-06-22 09:57:13', '2018-06-22 10:43:16'),
(15, 23, 'fh@yuh.hf', '2d7d7a97d38be4fd3aab778ae7546639', '93ae09b5', 2333, 0, '2018-06-22 09:57:13', '2018-06-22 10:43:16'),
(16, 24, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '44450edb', 2537, 0, '2018-06-22 10:43:16', '2018-06-22 14:45:21'),
(17, 24, 'hdg@td.ud', 'bd0be959e828ea5db3ce3d5b970cddfd', '946009b9', 2537, 0, '2018-06-22 10:43:16', '2018-06-22 14:45:22'),
(18, 24, 'fs@td.udj', '519f84d645e89e3a6dcc540fdefe6554', '956509ca', 2537, 0, '2018-06-22 10:43:17', '2018-06-22 14:45:22'),
(19, 25, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '43050ed2', 1948, 0, '2018-06-22 14:45:22', '2018-06-22 14:45:52'),
(20, 25, 'sdhf@gd.sdg', '88caf30e7a87d879cd60c22ba672b44c', 'aa450a7a', 1948, 0, '2018-06-22 14:45:22', '2018-06-22 14:45:52'),
(21, 25, 'gsd@ghd.du', '6addb0699a9f7d2d057809cb68582f4e', '9eca0a16', 1948, 0, '2018-06-22 14:45:22', '2018-06-22 14:45:52'),
(22, 26, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '43740ed5', 1948, 0, '2018-06-22 14:45:52', '2018-06-22 14:46:22'),
(23, 26, 'sdhf@gd.sdg', '88caf30e7a87d879cd60c22ba672b44c', 'aa930a7d', 1948, 0, '2018-06-22 14:45:52', '2018-06-22 14:46:22'),
(24, 26, 'gsd@ghd.du', '6addb0699a9f7d2d057809cb68582f4e', '9f150a19', 1948, 0, '2018-06-22 14:45:52', '2018-06-22 14:46:22'),
(25, 27, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '44070ed9', 1948, 0, '2018-06-22 14:46:23', '2018-06-22 14:46:58'),
(26, 27, 'sdhf@gd.sdg', '88caf30e7a87d879cd60c22ba672b44c', 'aafa0a81', 1948, 0, '2018-06-22 14:46:23', '2018-06-22 14:46:59'),
(27, 27, 'gsd@ghd.du', '6addb0699a9f7d2d057809cb68582f4e', '9f780a1d', 1948, 0, '2018-06-22 14:46:23', '2018-06-22 14:46:59'),
(28, 28, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '44020ed9', 1948, 0, '2018-06-22 14:46:59', '2018-06-22 14:48:00'),
(29, 28, 'sdhf@gd.sdg', '88caf30e7a87d879cd60c22ba672b44c', 'aaf50a81', 1948, 0, '2018-06-22 14:46:59', '2018-06-22 14:48:00'),
(30, 28, 'gsd@ghd.du', '6addb0699a9f7d2d057809cb68582f4e', '9f730a1d', 1948, 0, '2018-06-22 14:46:59', '2018-06-22 14:48:00'),
(31, 29, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '43c10ed7', 1948, 0, '2018-06-22 14:48:00', '2018-06-22 14:48:30'),
(32, 29, 'sdhf@gd.sdg', '88caf30e7a87d879cd60c22ba672b44c', 'aaca0a7f', 1948, 0, '2018-06-22 14:48:00', '2018-06-22 14:48:30'),
(33, 29, 'gsd@ghd.du', '6addb0699a9f7d2d057809cb68582f4e', '9f4a0a1b', 1948, 0, '2018-06-22 14:48:00', '2018-06-22 14:48:30'),
(38, 32, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '43e30ed8', 5455, 0, '2018-06-22 14:50:25', '2018-06-22 14:52:01'),
(39, 33, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '43790ed5', 5455, 0, '2018-06-22 14:52:01', '2018-06-22 14:53:36'),
(40, 34, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '417b0ec8', 5000, 0, '2018-06-22 14:53:36', '2018-06-22 16:58:09'),
(41, 35, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '427f0ecf', 5000, 2, '2018-06-22 14:54:55', '2018-06-22 14:55:19'),
(42, 36, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '420d0ecc', 5000, 0, '2018-06-22 14:55:19', '2018-06-22 14:55:30'),
(43, 37, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '41130ec5', 5000, 3, '2018-06-22 14:55:30', '2018-06-22 16:32:04'),
(44, 38, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '43950ed6', 1450, 0, '2018-06-22 16:32:05', '2018-06-22 16:58:09'),
(45, 38, 'hfg@fhh.syg', '9a637acdac48ff4ec84d29c963a68e7d', 'ab290a8e', 1450, 3, '2018-06-26 05:57:00', '2018-06-26 14:31:42'),
(46, 38, 'siud@hxh.fd', '34e470d979981ac3c49e6dac560926f1', 'ad090a97', 1450, 0, '2018-06-22 16:32:05', '2018-06-22 16:58:09'),
(50, 42, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '44710edc', 2732, 2, '2018-06-22 17:02:29', '2018-06-26 05:54:53'),
(51, 42, 'ss@fgg.fgh', '9e499a97ec89acb3ca814346d2950e32', 'a0250a25', 2732, 2, '2018-06-22 17:02:29', '2018-06-26 05:54:54'),
(52, 45, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '6b7a0f4f', 1247, 3, '2018-06-26 05:57:00', '2018-06-26 17:54:33'),
(53, 45, 'aa.bb@cc.com', '9945664ceb8250bb783b6f10adba037d', 'd5ec0b32', 1247, 0, '2018-06-26 05:57:00', '2018-06-26 17:57:23'),
(54, 45, 'nn.aa@ii.com', '5d30478508807af94a14864388f797d2', 'd9b80b5a', 1247, 0, '2018-06-26 05:57:00', '2018-06-26 17:57:23'),
(55, 46, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '7d530f99', 1067, 3, '2018-06-26 17:57:23', '2018-06-26 18:04:18'),
(56, 46, 'aa@bb.cc', 'b3b42315af060ac3c7a533ded7804112', 'a99e09d8', 1067, 3, '2018-06-26 17:57:23', '2018-06-26 18:04:26'),
(57, 46, 'bb@cc.dd', '67517a1d15e185773baf891ddc62ce29', 'a03609a0', 1067, 3, '2018-06-26 17:57:23', '2018-06-26 18:04:35'),
(58, 47, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '7cf50f93', 2127, 3, '2018-06-26 18:05:27', '2018-06-26 18:32:47'),
(59, 47, 'aa.bb@cc', 'd000511263c17c9a98dfeab214bc7fc8', 'a91809ca', 2127, 3, '2018-06-26 18:05:27', '2018-06-26 18:32:50'),
(60, 48, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '6d490f62', 1596, 3, '2018-06-26 18:07:50', '2018-06-26 18:33:02'),
(61, 48, 'aa@bb.cc', 'b3b42315af060ac3c7a533ded7804112', 'a95f09d9', 1596, 3, '2018-06-26 18:07:50', '2018-06-26 18:33:03'),
(62, 48, 'bb@cc.dd', '67517a1d15e185773baf891ddc62ce29', 'a9d309db', 1596, 3, '2018-06-26 18:07:50', '2018-06-26 18:33:07'),
(63, 49, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '7d420f8f', 1818, 3, '2018-06-26 18:10:26', '2018-06-26 18:33:31'),
(64, 49, 'aa@bb.cc', 'b3b42315af060ac3c7a533ded7804112', 'a99109d0', 1818, 3, '2018-06-26 18:10:26', '2018-06-26 18:33:34'),
(65, 49, 'bb@cc.dd', '67517a1d15e185773baf891ddc62ce29', 'aa3209e6', 1818, 3, '2018-06-26 18:10:26', '2018-06-26 18:33:46'),
(66, 50, 'okello.kepha@gmail.com', '5cc5cc0c4f9f0ce3506cb9c0025ff9ae', '7d1f0f95', 1518, 3, '2018-06-26 18:19:16', '2018-06-26 18:33:43'),
(67, 50, 'aa.bb@cc', 'd000511263c17c9a98dfeab214bc7fc8', 'a93e09d2', 1518, 1, '2018-06-26 18:19:16', '2018-06-26 18:19:16'),
(68, 50, 'cc@dd.ee', '1fc2101555345f13f586f31fd66c7cc8', 'a0a109af', 1518, 1, '2018-06-26 18:19:16', '2018-06-26 18:19:16');

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `distance` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`id`, `name`, `distance`, `created_at`, `updated_at`) VALUES
(1, 'Westlands', 10, NULL, NULL),
(2, 'Parklands 2nd Avenue', 15, NULL, NULL),
(3, 'Chaka Place', 20, NULL, NULL),
(4, 'Parklands 3rd Avenue', 18, NULL, NULL),
(5, 'Amboseli, Lavington', 25, NULL, NULL),
(6, 'Ngong - EmbulBul', 50, NULL, NULL),
(7, 'Umoja 1', 27, NULL, NULL),
(8, 'Umoja Phase 5', 33, NULL, NULL),
(9, 'Buru Buru', 14, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_06_21_152523_create_promo_code_amounts_table', 1),
(4, '2018_06_21_160937_generate_codes', 1),
(5, '2018_06_22_133000_create_codes_table', 2),
(6, '2018_06_25_184338_create_locations_table', 2),
(7, '2018_06_25_184504_used_codes', 2),
(8, '2018_06_25_184505_used_codes', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `promo_code_amounts`
--

CREATE TABLE `promo_code_amounts` (
  `id` int(10) UNSIGNED NOT NULL,
  `amount` int(11) NOT NULL,
  `recipients` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `promo_code_amounts`
--

INSERT INTO `promo_code_amounts` (`id`, `amount`, `recipients`, `created_at`, `updated_at`) VALUES
(1, 5000, 3, '2018-06-22 08:54:49', '2018-06-22 08:54:49'),
(2, 5000, 3, '2018-06-22 08:57:18', '2018-06-22 08:57:18'),
(3, 7000, 3, '2018-06-22 09:09:46', '2018-06-22 09:09:46'),
(4, 7000, 3, '2018-06-22 09:16:28', '2018-06-22 09:16:28'),
(5, 7000, 3, '2018-06-22 09:19:24', '2018-06-22 09:19:24'),
(6, 7000, 3, '2018-06-22 09:20:48', '2018-06-22 09:20:48'),
(7, 7000, 3, '2018-06-22 09:21:28', '2018-06-22 09:21:28'),
(8, 7000, 2, '2018-06-22 09:21:56', '2018-06-22 09:21:56'),
(9, 7000, 2, '2018-06-22 09:22:27', '2018-06-22 09:22:27'),
(10, 7000, 2, '2018-06-22 09:23:29', '2018-06-22 09:23:29'),
(11, 7000, 2, '2018-06-22 09:24:35', '2018-06-22 09:24:35'),
(12, 7000, 2, '2018-06-22 09:27:24', '2018-06-22 09:27:24'),
(13, 7000, 2, '2018-06-22 09:29:09', '2018-06-22 09:29:09'),
(14, 7000, 2, '2018-06-22 09:33:00', '2018-06-22 09:33:00'),
(15, 7000, 2, '2018-06-22 09:33:22', '2018-06-22 09:33:22'),
(16, 7000, 2, '2018-06-22 09:33:50', '2018-06-22 09:33:50'),
(17, 7000, 2, '2018-06-22 09:34:21', '2018-06-22 09:34:21'),
(18, 7000, 2, '2018-06-22 09:34:53', '2018-06-22 09:34:53'),
(19, 7000, 2, '2018-06-22 09:36:10', '2018-06-22 09:36:10'),
(20, 7000, 2, '2018-06-22 09:40:22', '2018-06-22 09:40:22'),
(21, 7000, 2, '2018-06-22 09:40:35', '2018-06-22 09:40:35'),
(22, 7000, 3, '2018-06-22 09:56:24', '2018-06-22 09:56:24'),
(23, 7000, 3, '2018-06-22 09:57:12', '2018-06-22 09:57:12'),
(24, 7612, 3, '2018-06-22 10:43:16', '2018-06-22 10:43:16'),
(25, 5845, 3, '2018-06-22 14:45:21', '2018-06-22 14:45:21'),
(26, 5845, 3, '2018-06-22 14:45:52', '2018-06-22 14:45:52'),
(27, 5845, 3, '2018-06-22 14:46:22', '2018-06-22 14:46:22'),
(28, 5845, 3, '2018-06-22 14:46:58', '2018-06-22 14:46:58'),
(29, 5845, 3, '2018-06-22 14:48:00', '2018-06-22 14:48:00'),
(30, 545555, 2, '2018-06-22 14:48:30', '2018-06-22 14:48:30'),
(31, 545555, 2, '2018-06-22 14:48:51', '2018-06-22 14:48:51'),
(32, 5455, 1, '2018-06-22 14:50:25', '2018-06-22 14:50:25'),
(33, 5455, 1, '2018-06-22 14:52:00', '2018-06-22 14:52:00'),
(34, 5000, 1, '2018-06-22 14:53:36', '2018-06-22 14:53:36'),
(35, 5000, 1, '2018-06-22 14:54:55', '2018-06-22 14:54:55'),
(36, 5000, 1, '2018-06-22 14:55:18', '2018-06-22 14:55:18'),
(37, 5000, 1, '2018-06-22 14:55:30', '2018-06-22 14:55:30'),
(38, 4350, 3, '2018-06-22 16:32:04', '2018-06-22 16:32:04'),
(39, 4844, 2, '2018-06-22 16:58:08', '2018-06-22 16:58:08'),
(40, 4844, 2, '2018-06-22 16:59:54', '2018-06-22 16:59:54'),
(41, 4844, 2, '2018-06-22 17:02:01', '2018-06-22 17:02:01'),
(42, 5465, 3, '2018-06-22 17:02:29', '2018-06-22 17:02:29'),
(43, 3741, 3, '2018-06-26 05:56:15', '2018-06-26 05:56:15'),
(44, 3741, 3, '2018-06-26 05:56:42', '2018-06-26 05:56:42'),
(45, 3741, 3, '2018-06-26 05:57:00', '2018-06-26 05:57:00'),
(46, 3201, 3, '2018-06-26 17:57:23', '2018-06-26 17:57:23'),
(47, 4254, 3, '2018-06-26 18:05:27', '2018-06-26 18:05:27'),
(48, 4788, 3, '2018-06-26 18:07:50', '2018-06-26 18:07:50'),
(49, 5455, 3, '2018-06-26 18:10:26', '2018-06-26 18:10:26'),
(50, 4554, 3, '2018-06-26 18:19:16', '2018-06-26 18:19:16');

-- --------------------------------------------------------

--
-- Table structure for table `used_codes`
--

CREATE TABLE `used_codes` (
  `id` int(10) UNSIGNED NOT NULL,
  `destination_id` int(10) UNSIGNED NOT NULL,
  `code_id` int(10) UNSIGNED NOT NULL,
  `total_amount` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `used_codes`
--

INSERT INTO `used_codes` (`id`, `destination_id`, `code_id`, `total_amount`, `created_at`, `updated_at`) VALUES
(2, 10, 52, 250, '2018-06-26 10:01:39', '2018-06-26 17:54:33'),
(3, 1, 45, 100, '2018-06-26 13:24:49', '2018-06-26 14:31:43'),
(4, 10, 55, 250, '2018-06-26 18:03:53', '2018-06-26 18:04:18'),
(5, 4, 56, 180, '2018-06-26 18:03:57', '2018-06-26 18:04:26'),
(6, 16, 57, 140, '2018-06-26 18:04:05', '2018-06-26 18:04:35'),
(7, 10, 59, 250, '2018-06-26 18:06:57', '2018-06-26 18:32:50'),
(8, 4, 58, 180, '2018-06-26 18:07:07', '2018-06-26 18:32:47'),
(9, 4, 62, 180, '2018-06-26 18:09:18', '2018-06-26 18:33:07'),
(10, 10, 61, 250, '2018-06-26 18:09:22', '2018-06-26 18:33:03'),
(11, 1, 60, 100, '2018-06-26 18:09:26', '2018-06-26 18:33:02'),
(12, 16, 63, 140, '2018-06-26 18:11:35', '2018-06-26 18:33:31'),
(13, 16, 64, 140, '2018-06-26 18:11:40', '2018-06-26 18:33:35'),
(14, 16, 65, 140, '2018-06-26 18:11:45', '2018-06-26 18:33:46'),
(15, 16, 66, 140, '2018-06-26 18:20:26', '2018-06-26 18:33:43');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `codes`
--
ALTER TABLE `codes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `generated_codes`
--
ALTER TABLE `generated_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `generated_codes_amount_id_index` (`amount_id`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `promo_code_amounts`
--
ALTER TABLE `promo_code_amounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `used_codes`
--
ALTER TABLE `used_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `used_codes_destination_id_index` (`destination_id`),
  ADD KEY `used_codes_code_id_index` (`code_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `codes`
--
ALTER TABLE `codes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `generated_codes`
--
ALTER TABLE `generated_codes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `promo_code_amounts`
--
ALTER TABLE `promo_code_amounts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `used_codes`
--
ALTER TABLE `used_codes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
